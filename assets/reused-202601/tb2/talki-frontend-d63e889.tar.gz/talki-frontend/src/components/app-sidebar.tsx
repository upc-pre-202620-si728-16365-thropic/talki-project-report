"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { toast } from "sonner";
import {
  LayoutDashboard,
  Mic,
  Trophy,
  ListVideo,
  LogOut,
  Settings,
  Plus,
  Loader2,
  MessageSquare,
  Video,
} from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import { auth, sessions as sessionsApi } from "@/lib/api/services";
import type { Session } from "@/lib/api/types";
import { useUser } from "@/components/user-context";
import { cn } from "@/lib/utils";

const LINKS = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/sessions", label: "Sesiones", icon: ListVideo },
  { href: "/coach", label: "Coach", icon: Mic },
  { href: "/leaderboard", label: "Ranking", icon: Trophy },
];

export function AppSidebar() {
  const user = useUser();
  const pathname = usePathname();
  const router = useRouter();
  const [recent, setRecent] = useState<Session[] | null>(null);
  const [loggingOut, setLoggingOut] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const accountRef = useRef<HTMLDivElement>(null);

  // Cerrar el menú de cuenta al hacer clic fuera o presionar Escape.
  useEffect(() => {
    if (!menuOpen) return;
    function onPointerDown(e: MouseEvent) {
      if (accountRef.current && !accountRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    }
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") setMenuOpen(false);
    }
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [menuOpen]);

  useEffect(() => {
    let alive = true;
    sessionsApi
      .list(user.userId)
      .then((list) => {
        if (!alive) return;
        const sorted = [...list].sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
        );
        setRecent(sorted.slice(0, 12));
      })
      .catch(() => alive && setRecent([]));
    return () => {
      alive = false;
    };
    // refetch al navegar (p. ej. tras crear una sesión)
  }, [user.userId, pathname]);

  async function handleLogout() {
    setLoggingOut(true);
    try {
      await auth.logout();
      toast.success("Sesión cerrada");
      router.replace("/login");
      router.refresh();
    } catch {
      toast.error("No se pudo cerrar sesión");
      setLoggingOut(false);
    }
  }

  const initial = user.email.charAt(0).toUpperCase();

  return (
    <aside className="flex h-screen w-64 shrink-0 flex-col border-r bg-sidebar border-sidebar-border">
      {/* Marca */}
      <div className="flex h-14 items-center justify-between border-b border-sidebar-border px-4">
        <div className="flex items-center gap-2.5">
          <div className="flex items-center justify-center size-9 rounded-xl bg-primary/10">
            <Video className="size-4 text-primary" />
          </div>
          <span className="text-lg font-semibold">Talki</span>
        </div>
        <ThemeToggle />
      </div>

      {/* Acción principal */}
      <div className="px-3 pt-4">
        <Link
          href="/sessions"
          className="flex items-center gap-2 rounded-lg bg-primary px-3 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
        >
          <Plus className="size-4" /> Nueva sesión
        </Link>
      </div>

      {/* Separador */}
      <div className="mx-3 my-3 h-px bg-sidebar-border" />

      {/* Navegación */}
      <nav className="space-y-0.5 px-3">
        {LINKS.map(({ href, label, icon: Icon }) => {
          const active =
            pathname === href ||
            (href !== "/sessions" && pathname.startsWith(`${href}/`)) ||
            (href === "/sessions" && pathname === "/sessions");
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition-colors",
                active
                  ? "bg-primary/10 font-medium text-primary"
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground",
              )}
            >
              <Icon className="size-4" />
              {label}
            </Link>
          );
        })}
      </nav>

      {/* Sesiones recientes */}
      <div className="mt-4 flex min-h-0 flex-1 flex-col px-3">
        <p className="px-3 pb-1 text-xs font-medium text-muted-foreground">
          Sesiones recientes
        </p>
        <div className="min-h-0 flex-1 space-y-0.5 overflow-y-auto">
          {recent === null ? (
            <div className="flex justify-center py-4">
              <Loader2 className="size-4 animate-spin text-muted-foreground" />
            </div>
          ) : recent.length === 0 ? (
            <p className="px-3 py-2 text-xs text-muted-foreground">Aún no hay sesiones.</p>
          ) : (
            recent.map((s) => {
              const active = pathname === `/sessions/${s.id}`;
              return (
                <Link
                  key={s.id}
                  href={`/sessions/${s.id}`}
                  title={s.title}
                  className={cn(
                    "flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm transition-colors",
                    active
                      ? "bg-primary/10 font-medium text-primary"
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground",
                  )}
                >
                  <MessageSquare className="size-3.5 shrink-0" />
                  <span className="truncate">{s.title}</span>
                </Link>
              );
            })
          )}
        </div>
      </div>

      {/* Cuenta */}
      <div ref={accountRef} className="relative border-t border-sidebar-border p-3">
        {menuOpen && (
          <div className="absolute right-3 bottom-full left-3 mb-1 overflow-hidden rounded-lg border bg-popover p-1 text-popover-foreground shadow-md">
            <p className="truncate px-2 py-1 text-xs font-medium text-muted-foreground">
              {user.email}
            </p>
            <div className="my-1 h-px bg-border" />
            <button
              type="button"
              onClick={handleLogout}
              disabled={loggingOut}
              className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-sm text-destructive transition-colors hover:bg-destructive/10 disabled:pointer-events-none disabled:opacity-50"
            >
              {loggingOut ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <LogOut className="size-4" />
              )}
              Cerrar sesión
            </button>
          </div>
        )}
        <button
          type="button"
          aria-haspopup="menu"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((open) => !open)}
          className="flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-muted"
        >
          <span className="grid size-8 shrink-0 place-items-center rounded-full bg-primary text-sm font-semibold text-primary-foreground">
            {initial}
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm font-medium">{user.email}</span>
            <span className="block text-xs text-muted-foreground">Mi cuenta</span>
          </span>
          <Settings className="size-4 shrink-0 text-muted-foreground" />
        </button>
      </div>
    </aside>
  );
}
